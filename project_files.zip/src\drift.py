import os
import pandas as pd
import numpy as np
import logging
from evidently.report import Report
from evidently.metric_preset import DataDriftPreset, TargetDriftPreset
from src.config import DRIFT_THRESHOLD
from src.database import fetch_data_from_db

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

def check_for_drift() -> bool:
    """
    Compares historical baseline data (reference) against a new batch of data (current).
    Uses Evidently AI to generate a drift dashboard and detect dataset drift.
    Returns True if data drift is detected (requiring retraining), False otherwise.
    """
    try:
        df = fetch_data_from_db("loans")
    except Exception as e:
        logging.error(f"Error fetching data from DB for drift check: {e}")
        return False

    if len(df) < 100:
        logging.warning("Not enough data to check for drift. Need at least 100 rows.")
        return False
        
    # Split data to simulate Reference (training data, e.g. first 80%) 
    # and Current (new inference data, e.g. last 20%)
    split_idx = int(len(df) * 0.8)
    reference_data = df.iloc[:split_idx].copy()
    current_data = df.iloc[split_idx:].copy()
    
    # Drop columns that are not predictive features
    columns_to_drop = ['sk_id_curr', 'created_at']
    for col in columns_to_drop:
        if col in reference_data.columns:
            reference_data = reference_data.drop(columns=[col])
        if col in current_data.columns:
            current_data = current_data.drop(columns=[col])
            
    logging.info(f"Comparing Reference ({len(reference_data)} rows) and Current ({len(current_data)} rows) datasets...")
    
    # Setup Evidently Report
    report = Report(metrics=[
        DataDriftPreset(),
        TargetDriftPreset()
    ])
    
    try:
        report.run(reference_data=reference_data, current_data=current_data)
        
        # Ensure reports directory exists
        os.makedirs("reports", exist_ok=True)
        report_html_path = "reports/data_drift_report.html"
        report.save_html(report_html_path)
        logging.info(f"Evidently drift dashboard saved to {report_html_path}")
        
        # Extract drift metrics
        report_dict = report.as_dict()
        
        # Check drift detection status
        # Evidently structure: metrics[0] is DataDriftPreset, result contains dataset_drift (bool)
        metrics_results = report_dict.get("metrics", [])
        
        drift_detected = False
        for metric in metrics_results:
            metric_type = metric.get("metric")
            metric_result = metric.get("result", {})
            
            if "DatasetDriftMetric" in metric_type or "dataset_drift" in metric_result:
                drift_detected = metric_result.get("dataset_drift", False)
                share_drifted_features = metric_result.get("share_of_drifted_features", 0.0)
                logging.info(f"Dataset Drift Detected: {drift_detected} (Drifted Feature Share: {share_drifted_features:.2%})")
                break
        
        # Fallback metric parsing if the structure differs
        if not metrics_results:
            # Let's count drifted features manually from the report details
            # Default behavior is that if > 50% features drifted, we trigger retraining
            drifted_features = report_dict.get("metrics", [{}])[0].get("result", {}).get("number_of_drifted_features", 0)
            total_features = report_dict.get("metrics", [{}])[0].get("result", {}).get("number_of_features", 1)
            share = drifted_features / total_features
            drift_detected = share > 0.5
            logging.info(f"Fallback check - Drifted features share: {share:.2%}")

        return drift_detected

    except Exception as e:
        logging.error(f"Error running Evidently drift analysis: {e}")
        # Return False so we don't trigger retraining on configuration/library errors
        return False

if __name__ == "__main__":
    drift = check_for_drift()
    print(f"Drift detected: {drift}")
