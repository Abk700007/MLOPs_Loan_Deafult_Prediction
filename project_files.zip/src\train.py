import pandas as pd
import numpy as np
import logging
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import roc_auc_score, accuracy_score, precision_score, recall_score, f1_score
import xgboost as xgb
import mlflow
import mlflow.xgboost
from src.config import MLFLOW_TRACKING_URI, EXPERIMENT_NAME, MODEL_NAME
from src.database import fetch_data_from_db

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

def preprocess_data(df: pd.DataFrame):
    """
    Cleans and prepares data for XGBoost.
    Handles encoding of categorical variables.
    """
    logging.info("Preprocessing data...")
    
    # Copy DataFrame to avoid modifying original
    data = df.copy()
    
    # Drop timestamp column and client ID from features
    if 'created_at' in data.columns:
        data = data.drop(columns=['created_at'])
    if 'sk_id_curr' in data.columns:
        data = data.drop(columns=['sk_id_curr'])
        
    # Split features and target
    X = data.drop(columns=['target'])
    y = data['target']
    
    # Handle categorical variables (LabelEncoding is fine for trees)
    categorical_cols = X.select_dtypes(include=['object']).columns.tolist()
    label_encoders = {}
    
    for col in categorical_cols:
        le = LabelEncoder()
        # Convert to string and handle nulls
        X[col] = X[col].astype(str)
        X[col] = le.fit_transform(X[col])
        label_encoders[col] = le
        
    return X, y, label_encoders

def train_model():
    """Fetches data, preprocesses it, trains an XGBoost classifier, and logs to MLflow."""
    # 1. Fetch data from Supabase database
    try:
        df = fetch_data_from_db("loans")
    except Exception as e:
        logging.error(f"Failed to fetch data for training: {e}")
        return None
        
    if len(df) < 50:
        logging.warning("Not enough records in the database to train a model. Need at least 50 records.")
        return None
        
    # 2. Preprocess features
    X, y, encoders = preprocess_data(df)
    
    # 3. Train / Test Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    
    # Handle class imbalance for XGBoost using scale_pos_weight
    ratio = (len(y_train) - sum(y_train)) / sum(y_train) if sum(y_train) > 0 else 1.0
    
    # 4. Initialize MLflow Experiment
    if MLFLOW_TRACKING_URI:
        logging.info(f"Setting MLflow tracking URI: {MLFLOW_TRACKING_URI}")
        mlflow.set_tracking_uri(MLFLOW_TRACKING_URI)
    
    mlflow.set_experiment(EXPERIMENT_NAME)
    
    # XGBoost Hyperparameters
    params = {
        "n_estimators": 100,
        "max_depth": 5,
        "learning_rate": 0.05,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "scale_pos_weight": ratio,
        "random_state": 42,
        "use_label_encoder": False,
        "eval_metric": "logloss"
    }
    
    logging.info("Starting model training run...")
    with mlflow.start_run() as run:
        # Train model
        model = xgb.XGBClassifier(**params)
        model.fit(X_train, y_train)
        
        # Predict & evaluate
        y_pred = model.predict(X_test)
        y_prob = model.predict_proba(X_test)[:, 1]
        
        # Calculate metrics
        metrics = {
            "roc_auc": roc_auc_score(y_test, y_prob),
            "accuracy": accuracy_score(y_test, y_pred),
            "precision": precision_score(y_test, y_pred, zero_division=0),
            "recall": recall_score(y_test, y_pred, zero_division=0),
            "f1": f1_score(y_test, y_pred, zero_division=0)
        }
        
        logging.info(f"Metrics: {metrics}")
        
        # Log to MLflow
        mlflow.log_params(params)
        mlflow.log_metrics(metrics)
        
        # Log the preprocessing info as an artifact
        mlflow.log_dict({"categorical_encoders": list(encoders.keys())}, "preprocessing_info.json")
        
        # Log and Register the Model in MLflow Model Registry
        logging.info(f"Logging and registering model under name '{MODEL_NAME}'...")
        mlflow.xgboost.log_model(
            xgb_model=model,
            artifact_path="model",
            registered_model_name=MODEL_NAME
        )
        
        logging.info(f"Model training successfully completed. Run ID: {run.info.run_id}")
        return run.info.run_id

if __name__ == "__main__":
    train_model()
