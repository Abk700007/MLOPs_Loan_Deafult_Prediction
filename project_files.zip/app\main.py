import os
import pandas as pd
import numpy as np
import logging
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import mlflow
import mlflow.pyfunc
from src.config import MLFLOW_TRACKING_URI, MODEL_NAME

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# Set MLflow environment variables if configured
if MLFLOW_TRACKING_URI:
    mlflow.set_tracking_uri(MLFLOW_TRACKING_URI)

app = FastAPI(
    title="Loan Default Prediction Service",
    description="API to predict the probability of a borrower defaulting on a loan.",
    version="1.0.0"
)

# Global model variable
model = None

class LoanApplication(BaseModel):
    code_gender: str = Field(description="Gender of the client (M, F, XNA)")
    flag_own_car: str = Field(description="Does the client own a car? (Y, N)")
    flag_own_realty: str = Field(description="Does the client own real estate? (Y, N)")
    cnt_children: int = Field(default=0, ge=0, description="Number of children")
    amt_income_total: float = Field(ge=0.0, description="Total income of client")
    amt_credit: float = Field(ge=0.0, description="Credit amount of the loan")
    amt_annuity: float = Field(ge=0.0, description="Loan annuity")
    amt_goods_price: float = Field(ge=0.0, description="Price of the goods for which the loan is given")
    days_birth: int = Field(le=0, description="Age in days (negative number, e.g. -12000)")
    days_employed: int = Field(description="Days employed (negative number, or 365243 for retired/unemployed)")
    ext_source_2: float = Field(ge=0.0, le=1.0, description="Score from external data source 2")
    ext_source_3: float = Field(default=0.5, ge=0.0, le=1.0, description="Score from external data source 3")

    class Config:
        schema_extra = {
            "example": {
                "code_gender": "F",
                "flag_own_car": "N",
                "flag_own_realty": "Y",
                "cnt_children": 0,
                "amt_income_total": 135000.0,
                "amt_credit": 312682.0,
                "amt_annuity": 15000.0,
                "amt_goods_price": 297000.0,
                "days_birth": -15000,
                "days_employed": -2500,
                "ext_source_2": 0.65,
                "ext_source_3": 0.52
            }
        }

@app.on_event("startup")
def load_registered_model():
    """Loads the production model from the MLflow model registry."""
    global model
    logging.info("Starting up API and attempting to load model from registry...")
    
    try:
        # Load from registry using the "Production" alias/stage
        # Alternatively, fallback to latest run if no production alias is set yet
        model_uri = f"models:/{MODEL_NAME}/Production"
        logging.info(f"Loading model from URI: {model_uri}")
        model = mlflow.pyfunc.load_model(model_uri)
        logging.info("Model loaded successfully.")
    except Exception as e:
        logging.warning(f"Failed to load production model from registry: {e}")
        logging.info("Attempting to load model from Staging instead...")
        try:
            model_uri = f"models:/{MODEL_NAME}/Staging"
            model = mlflow.pyfunc.load_model(model_uri)
            logging.info("Staging model loaded successfully.")
        except Exception as e_staging:
            logging.error(f"Failed to load staging model: {e_staging}. Predictions will not work until a model is registered.")
            model = None

@app.get("/health")
def health_check():
    """Endpoint to check health of service and if the model is loaded."""
    return {
        "status": "healthy",
        "model_loaded": model is not None,
        "model_name": MODEL_NAME
    }

def preprocess_application(app_data: LoanApplication) -> pd.DataFrame:
    """Preprocesses Pydantic data class into the exact shape and encoding needed by XGBoost."""
    
    # Categorical mapping matching sklearn LabelEncoder sort order
    gender_map = {'F': 0, 'M': 1, 'XNA': 2}
    car_map = {'N': 0, 'Y': 1}
    realty_map = {'N': 0, 'Y': 1}
    
    data_dict = {
        "code_gender": gender_map.get(app_data.code_gender.upper(), 0),
        "flag_own_car": car_map.get(app_data.flag_own_car.upper(), 0),
        "flag_own_realty": realty_map.get(app_data.flag_own_realty.upper(), 0),
        "cnt_children": app_data.cnt_children,
        "amt_income_total": app_data.amt_income_total,
        "amt_credit": app_data.amt_credit,
        "amt_annuity": app_data.amt_annuity,
        "amt_goods_price": app_data.amt_goods_price,
        "days_birth": app_data.days_birth,
        "days_employed": app_data.days_employed,
        "ext_source_2": app_data.ext_source_2,
        "ext_source_3": app_data.ext_source_3
    }
    
    # Return as DataFrame with single row
    return pd.DataFrame([data_dict])

@app.post("/predict")
def predict_default(application: LoanApplication):
    """
    Receives loan application data and returns probability of default.
    """
    global model
    if model is None:
        raise HTTPException(status_code=503, detail="Model is currently not loaded or registered on MLflow. Please check logs.")
        
    try:
        # Preprocess features
        features_df = preprocess_application(application)
        
        # XGBoost prediction
        # Use pyfunc predict which returns a numpy array of predictions or probabilities
        # Depending on how the model is logged, we might need model.unwrap_python_model().predict_proba()
        # For general mlflow pyfunc, predict() often returns predictions. 
        # To make it robust, we can run predict on the underlying XGBoost model if needed:
        raw_model = model._model_impl
        
        # Make prediction
        prob = raw_model.predict_proba(features_df)[0][1]
        prediction = int(raw_model.predict(features_df)[0])
        
        return {
            "default_probability": float(prob),
            "default_prediction": prediction,
            "risk_status": "High Risk" if prob > 0.5 else "Low Risk"
        }
        
    except Exception as e:
        logging.error(f"Error during prediction: {e}")
        raise HTTPException(status_code=500, detail=f"Prediction error: {str(e)}")
