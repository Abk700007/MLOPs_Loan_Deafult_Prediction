import pandas as pd
import psycopg2
from psycopg2 import sql
import logging
from src.config import DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

def get_connection():
    """Establishes connection to the PostgreSQL database."""
    try:
        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            user=DB_USER,
            password=DB_PASSWORD,
            dbname=DB_NAME
        )
        return conn
    except Exception as e:
        logging.error(f"Error connecting to database: {e}")
        raise

def initialize_database():
    """Creates the necessary tables if they do not exist."""
    conn = get_connection()
    cursor = conn.cursor()
    
    # We will define a subset of features from Home Credit Default Risk dataset
    create_table_query = """
    CREATE TABLE IF NOT EXISTS loans (
        sk_id_curr INT PRIMARY KEY,
        target INT,
        code_gender VARCHAR(10),
        flag_own_car VARCHAR(5),
        flag_own_realty VARCHAR(5),
        cnt_children INT,
        amt_income_total DOUBLE PRECISION,
        amt_credit DOUBLE PRECISION,
        amt_annuity DOUBLE PRECISION,
        amt_goods_price DOUBLE PRECISION,
        days_birth INT,
        days_employed INT,
        ext_source_2 DOUBLE PRECISION,
        ext_source_3 DOUBLE PRECISION,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """
    try:
        cursor.execute(create_table_query)
        conn.commit()
        logging.info("Database initialized and 'loans' table created successfully.")
    except Exception as e:
        conn.rollback()
        logging.error(f"Failed to initialize database: {e}")
        raise
    finally:
        cursor.close()
        conn.close()

def save_data_to_db(df: pd.DataFrame, table_name: str = "loans"):
    """Inserts a pandas DataFrame into the specified table in PostgreSQL."""
    if df.empty:
        logging.warning("DataFrame is empty. Skipping save.")
        return

    conn = get_connection()
    cursor = conn.cursor()
    
    # Normalize columns to lowercase matching PostgreSQL schema
    df.columns = [col.lower() for col in df.columns]
    
    # Generate insert query dynamically
    columns = list(df.columns)
    query = sql.SQL("INSERT INTO {table} ({fields}) VALUES ({values}) ON CONFLICT (sk_id_curr) DO NOTHING").format(
        table=sql.Identifier(table_name),
        fields=sql.SQL(', ').join(map(sql.Identifier, columns)),
        values=sql.SQL(', ').join(sql.Placeholder() * len(columns))
    )
    
    try:
        # Convert df values to Python types for inserting
        records = [tuple(row) for row in df.itertuples(index=False, name=None)]
        cursor.executemany(query, records)
        conn.commit()
        logging.info(f"Successfully loaded {len(records)} records into table '{table_name}'.")
    except Exception as e:
        conn.rollback()
        logging.error(f"Error loading records into table: {e}")
        raise
    finally:
        cursor.close()
        conn.close()

def fetch_data_from_db(table_name: str = "loans") -> pd.DataFrame:
    """Queries all records from the database and returns them as a pandas DataFrame."""
    conn = get_connection()
    query = f"SELECT * FROM {table_name}"
    try:
        df = pd.read_sql_query(query, conn)
        logging.info(f"Successfully fetched {len(df)} records from table '{table_name}'.")
        return df
    except Exception as e:
        logging.error(f"Error fetching data from database: {e}")
        raise
    finally:
        conn.close()
